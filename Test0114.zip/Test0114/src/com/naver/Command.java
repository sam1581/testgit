package com.naver;

public interface Command {

}
