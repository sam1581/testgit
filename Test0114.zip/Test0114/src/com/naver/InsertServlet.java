package com.naver;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = getInitParameter("user");
		System.out.println(user);
		
		String password = getInitParameter("password");
		System.out.println(password);
		
		ServletContext ctx = getServletContext();
		String driver = ctx.getInitParameter("driver");
		System.out.println(driver);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("euc-kr");
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String sAge = request.getParameter("age");
		
		int age = -1;
		if(sAge != null) {
			age = Integer.parseInt(sAge);   //넘겨준 데이터를 받는 소스
		}
		
		MemberDAO dao = new MemberDAO(); //db로 넘겨주어야 하는데, 직접적으로 연결되어 있는 것은  MemberDAO
		dao.insert(new MemberDTO(id, name, age));
		
		
		// 브라우저로 보내는 소스
		response.setContentType("text/html;charset=euc-kr");
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print(id);
		out.print("<br>");
		out.print(name);
		out.print("<br>");
		out.print(age);
		out.print("</body>");
		out.print("</html>");
		
		
	}

}
