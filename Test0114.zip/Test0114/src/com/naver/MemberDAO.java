package com.naver;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class MemberDAO {

	private final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	private final String URL = "jdbc:orcale:thin:@localhost:1521:xe";
	private final String USER = "ca2";
	private final String PASSWORD = "ca2";
	
	public MemberDAO() {
	
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 연결 실패");
		}
	
	}


	
	public void insert(MemberDTO dto) {
		
		Connection conn = null; 
		PreparedStatement pstmt = null;
		String sql = "insert into member2 values(?, ?, ?)";
		
		try {
			
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setInt(3, dto.getAge());
			pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			try {
				if(pstmt != null) {
					pstmt.close();
				}
				if(conn != null) {
					conn.close();
				}
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	
		
		
				
				
		
		
	}
	
	
	
	
	
}
